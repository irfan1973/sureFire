import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class EmailService {
  constructor(private http: HttpClient) {}

  email(emailparams: any) {
    // from: req.body.from, //"contact@rockyroadsolutions.com",
    // to: req.body.to,
    // subject: req.body.subject,
    // text: req.body.message,

    return this.http.post('http://localhost:3000/email', emailparams);
  }
}
