import { Component } from '@angular/core';
import { ServicesComponent } from '../services/services.component';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-career',
  templateUrl: './career.component.html',
  styleUrls: ['./career.component.css'],
})
export class CareerComponent {
  uploadedFiles: any;

  constructor(
    private _services: ServicesComponent,
    private toastr: ToastrService
  ) {}

  onfileSelected(event: any) {
    this.uploadedFiles = event.target.files;
  }

  onSubmit() {
    if (this.uploadedFiles == undefined) {
      this.toastr.error('Please select file to upload.', 'Error');
    }
    let formData = new FormData();
    for (var i = 0; i < this.uploadedFiles.length; i++) {
      formData.append(
        'uploads[]',
        this.uploadedFiles[i],
        this.uploadedFiles[i].name
      );
    }

    this._services.uploadFile(formData).subscribe((res: any) => {
      if (res.status == 'Error') this.toastr.error(res.message, 'Error');
      else this.toastr.success(res.message, 'Success');
    });
  }
}
