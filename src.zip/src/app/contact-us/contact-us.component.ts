import { Component } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { EmailService } from '../services/email.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css'],
})
export class ContactUsComponent {
  username: string = '';
  phone: string = '';
  company: string = '';
  email: string = '';
  zip: string = '';
  help: string = '';
  message: string = '';

  profileForm: FormGroup;
  submitted = false;

  constructor(
    private builder: FormBuilder,
    private _emailservice: EmailService
  ) {
    this.profileForm = new FormGroup([]);
  }

  onSubmit() {
    let emailParams: any = {};

    emailParams.from = this.email;
    emailParams.to = 'irfan.gill@gmail.com';
    emailParams.cc = 'faheem.ullah@gmail.com';
    emailParams.subject = 'Client Contacted for sales@surefiresecurity.com';
    emailParams.message = this.message;

    this._emailservice.email(emailParams).subscribe((res) => {
      console.log(res);
    });
  }
}
